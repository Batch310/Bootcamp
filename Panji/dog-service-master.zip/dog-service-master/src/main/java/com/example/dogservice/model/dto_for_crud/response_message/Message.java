package com.example.dogservice.model.dto_for_crud.response_message;

public class Message {
    public String message;

    public Message(String message) {
        this.message = message;

    }
}
